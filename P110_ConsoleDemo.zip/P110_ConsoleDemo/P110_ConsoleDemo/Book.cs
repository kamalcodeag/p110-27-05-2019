﻿namespace P110_ConsoleDemo
{
    public class Book : ReadableItem
    {
    }

}
