﻿namespace P110_ConsoleDemo
{
    public class Encyclopedia : ReadableItem
    {
    }

}
