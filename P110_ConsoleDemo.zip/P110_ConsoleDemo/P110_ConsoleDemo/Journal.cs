﻿namespace P110_ConsoleDemo
{
    public class Journal : ReadableItem
    {
    }

}
