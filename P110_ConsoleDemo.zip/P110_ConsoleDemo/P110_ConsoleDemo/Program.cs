﻿using System;
using System.Net.Mail;
using System.Text;
using PrimaryClasses;

namespace P110_ConsoleDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Homework with indexer
            //Library libraff = new Library();

            //Book book1 = new Book()
            //{
            //    ISBN = "123AB",
            //    Name = "Leyli & Mecnun",
            //    Author = "N. Gencevi",
            //    Count = 100,
            //    Price = 20
            //};

            //Book book2 = new Book
            //{
            //    ISBN = "123ABS",
            //    Name = "Xosrov & Sirin",
            //    Author = "N. Gencevi",
            //    Count = 50,
            //    Price = 15,
            //    HasDiscount = false,
            //    DiscountPercent = 0.1F
            //};

            //libraff.AddBook(book1);
            //libraff.AddBook(book2);

            //Console.WriteLine(libraff[0]);
            //libraff[0] = new Book { ISBN = "123ASDF", Name = "Samir", Author = "Samir" };
            //Console.WriteLine(libraff[0]);

            //Journal journal1 = new Journal
            //{
            //    ISBN = "ADS124",
            //    Name = "JR",
            //    Author = "N. Gencevi",
            //    Count = 500,
            //    Price = 50
            //};

            //Journal journal2 = new Journal
            //{
            //    ISBN = "ADS1245",
            //    Name = "JR 2",
            //    Author = "M. Gencevi",
            //    Count = 50,
            //    Price = 5
            //};

            //Encyclopedia encyclopedia1 = new Encyclopedia
            //{
            //    ISBN = "AQ123DF",
            //    Name = "N. Gencevinin tarixi",
            //    Author = "N. Gencevi",
            //    Count = 10,
            //    Price = 50000,
            //    HasDiscount = true,
            //    DiscountPercent = 0.99F
            //};


            //libraff.AddEncyclopedia(encyclopedia1);
            //libraff.AddJournal(journal1);
            //libraff.AddJournal(journal2);
            #endregion

            #region Extension methods
            //string myemail = "samir.d@code.edu.az";
            //Console.WriteLine(myemail.IsEmail());

            //int a = 5;
            //Console.WriteLine(a.Pow(3));

            //Journal journal = new Journal();
            //journal.Demo();
            #endregion

            #region Boxing & unboxing
            //int a = 5;

            ////boxing (implicit)
            //object obj = a;
            //a = 15;

            //Console.WriteLine(obj);
            //if (obj is int)
            //{
            //    //unboxing (explicit)
            //    int b = (int)obj;
            //}
            #endregion

            //enum
            //Generic type
            //interface
            //struct
            //Collections & Collections.Generic namespace
            //delegate
            //event
            //Thread, Task
            //Reflection
        }

        static bool IsEmail(string demo)
        {
            return true;
        }
    }

    
}

